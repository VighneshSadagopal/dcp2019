<?php

// Application 'drupalcamppune', environment 'dev'.
$aliases['dev'] = array (
  'root' => '/var/www/html/drupalcamppune.dev/docroot',
  'ac-site' => 'drupalcamppune',
  'ac-env' => 'dev',
  'ac-realm' => 'prod',
  'uri' => 'drupalcamppunedev.prod.acquia-sites.com',
  'path-aliases' => 
  array (
    '%drush-script' => 'drush8',
  ),
  'dev.livedev' => 
  array (
    'parent' => '@drupalcamppune.dev',
    'root' => '/mnt/gfs/drupalcamppune.dev/livedev/docroot',
  ),
  'remote-host' => 'drupalcamppunedev.ssh.prod.acquia-sites.com',
  'remote-user' => 'drupalcamppune.dev',
);

// Application 'drupalcamppune', environment 'prod'.
$aliases['prod'] = array (
  'root' => '/var/www/html/drupalcamppune.prod/docroot',
  'ac-site' => 'drupalcamppune',
  'ac-env' => 'prod',
  'ac-realm' => 'prod',
  'uri' => 'drupalcamppune.prod.acquia-sites.com',
  'path-aliases' => 
  array (
    '%drush-script' => 'drush8',
  ),
  'prod.livedev' => 
  array (
    'parent' => '@drupalcamppune.prod',
    'root' => '/mnt/gfs/drupalcamppune.prod/livedev/docroot',
  ),
  'remote-host' => 'drupalcamppune.ssh.prod.acquia-sites.com',
  'remote-user' => 'drupalcamppune.prod',
);

// Application 'drupalcamppune', environment 'test'.
$aliases['test'] = array (
  'root' => '/var/www/html/drupalcamppune.test/docroot',
  'ac-site' => 'drupalcamppune',
  'ac-env' => 'test',
  'ac-realm' => 'prod',
  'uri' => 'drupalcamppunetest.prod.acquia-sites.com',
  'path-aliases' => 
  array (
    '%drush-script' => 'drush8',
  ),
  'test.livedev' => 
  array (
    'parent' => '@drupalcamppune.test',
    'root' => '/mnt/gfs/drupalcamppune.test/livedev/docroot',
  ),
  'remote-host' => 'drupalcamppunetest.ssh.prod.acquia-sites.com',
  'remote-user' => 'drupalcamppune.test',
);

